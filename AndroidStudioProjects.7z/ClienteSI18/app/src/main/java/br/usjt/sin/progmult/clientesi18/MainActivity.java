package br.usjt.sin.progmult.clientesi18;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends Activity {
    private EditText editText;
    public static final String BUSCA = "br.usjt.sin.progmult.clientesi18.busca";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = findViewById(R.id.txt_busca);
    }

    public void buscarClientes(View view) {
        String text = editText.getText().toString(); /* pegar o texto digitado */
        Intent intent = new Intent(this,ListaClientesActivity.class); /* instanciar classe pegando como String */
        intent.putExtra(BUSCA, text); /* passar parametros para a próxima activity */
        startActivity(intent);
    }
}
